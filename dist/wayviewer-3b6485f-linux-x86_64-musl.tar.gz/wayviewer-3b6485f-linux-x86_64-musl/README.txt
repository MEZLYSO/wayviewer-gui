WayViewer 3b6485f (musl) - Administración

Esta es la versión de administración: envía las órdenes de bloqueo de entrada
y ping al equipo cliente y puede suspenderlo remotamente. No necesita
nftables ni un helper local.

Dependencias del sistema:
  - Python 3 + tkinter
  - FFmpeg (ffplay)
  - libsrt ABI 1.5, libwayland, libdrm, mesa (para el binario wayviewer)
  - gtk3 (opcional, para el selector de archivos nativo)

Ejecutar:
  ./run.sh

Instalar en Mint/Debian, Arch o Void Linux (requiere un binario compatible):
  sudo ./packaging/install-admin.sh $USER

El instalador instala dependencias con apt, pacman o xbps-install y comprueba
libc y ABI. El binario incluido es musl, por lo que encaja con Void Linux (musl).
En Void glibc u otra ABI, proporciona un build nativo:
  sudo env WAYVIEWER_BIN=/ruta/wayviewer ./packaging/install-admin.sh $USER

Bloqueo de /etc/hosts:
  Esta función edita la sección de hosts únicamente en el equipo cliente.

Descubrimiento LAN/VPN:
  El panel muestra clientes que anuncian UDP en el puerto 9501. Si los
  clientes están tras VPN, configura WAYVIEWER_SERVER_IP en cada cliente.

Variables útiles:
  WAYVIEWER_BIN=/ruta/alternativa/wayviewer
  WAYVIEWER_CHAT_PORT=9500
  WAYVIEWER_DISCOVERY_PORT=9501
  WAYVIEWER_UNIX_SOCKET=/tmp/wayviewer-$UID.sock
