WayViewer f0950a7 (musl) - Cliente

Esta es la versión cliente: recibe órdenes de bloqueo de entrada y ping, y
puede suspenderse desde el panel de administración. Al iniciar, pide la
contraseña local de sudo y la conserva únicamente en memoria hasta cerrar.

Dependencias del sistema:
  - Python 3 + tkinter
  - FFmpeg (ffplay)
  - libsrt ABI 1.5, libwayland, libdrm, mesa (para el binario wayviewer)
  - gtk3 (opcional, para el selector de archivos nativo)

Ejecutar:
  ./run.sh

Instalar en Mint/Debian, Arch o Void Linux (requiere un binario compatible):
  sudo ./packaging/install-master.sh $USER

Bloqueo de ping y hosts del cliente (una vez, como root):
  Instala nftables con el gestor de tu distro, por ejemplo:
    Debian/Mint: sudo apt install nftables
    Arch:        sudo pacman -S nftables
    Void:        sudo xbps-install -S nftables
  Después ejecuta:
    sudo ./install-nft-helper.sh $USER
    sudo ./install-hosts-helper.sh $USER

El cliente pide la contraseña local al cambiar el bloqueo o suspender.
Para habilitar suspensión remota, instala el helper una vez:
  sudo ./install-power-helper.sh $USER

El instalador instala dependencias con apt, pacman o xbps-install y comprueba
libc y ABI. El binario incluido es musl, por lo que encaja con Void Linux (musl).
En Void glibc u otra ABI, proporciona un build nativo:
  sudo env WAYVIEWER_BIN=/ruta/al/wayviewer ./packaging/install-master.sh $USER

Descubrimiento LAN/VPN:
  Este cliente anuncia su presencia por UDP en el puerto 9501. En LAN usa
  broadcast; si los equipos están conectados por VPN, define la IP del admin
  con WAYVIEWER_SERVER_IP para enviar el anuncio de forma dirigida.

Variables útiles:
  WAYVIEWER_BIN=/ruta/alternativa/wayviewer
  WAYVIEWER_CHAT_PORT=9500
  WAYVIEWER_DISCOVERY_PORT=9501
  WAYVIEWER_SERVER_IP=10.8.0.1
  WAYVIEWER_UNIX_SOCKET=/tmp/wayviewer-$UID.sock
